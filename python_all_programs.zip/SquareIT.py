def squareIT(number):
    print("The Square of",number ,"is",number*number)

squareIT(4)
squareIT(5)