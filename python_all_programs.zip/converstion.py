
def kg_to_pounds(kg):
    pounds = kg * 2.20462
    return pounds
kg = float(input("Enter weight in kilograms: "))
pounds = kg_to_pounds(kg)
print(f"{kg} kg is equal to {pounds:.2f} pounds")
