text = "Hello World"
char_list = list(text)
print(char_list)
