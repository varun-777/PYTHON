class Test:
    def m1(self):
        a = 1000  
        print(a)

    def m2(self):
        b = 2000  
        print( b)



t = Test()


t.m1()
t.m2()
