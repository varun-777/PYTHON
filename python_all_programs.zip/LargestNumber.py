numbers = [12, 45, 2, 98, 23, 67, 89]
largest = max(numbers)
print("The largest number is:", largest)