class Animal:
    def __init__(self, name):  # corrected __init__
        self.name = name

    def eat(self):
        print(f"{self.name} is eating.")

class Dog(Animal):
    def bark(self):
        print(f"{self.name} is barking.")

class Cat(Animal):
    def meow(self):
        print(f"{self.name} is meowing.")

# Create objects
dog = Dog("Buddy")
cat = Cat("Whiskers")

# Call methods
dog.eat()
dog.bark()
cat.eat()
cat.meow()
