class Student:
    def __del__(self):
        print("Destructor called, object deleted")

s = Student()
del s
