class uni:
def soe(self,name);
self.name = name
if self.name == 'adithya' :
    branch = "CSE"
    else:
        branch = "MECH"
        return name,branch
        a = uni()
        a.soe("Pravallika")
        