class student:
def_init_(selfx,y,z);
self.name=x
self.rollno=y
self.marks=z

   def display(self):
    print("Student Name:{}\nRollno:{}".format(self.name,self.rollno,self.marks))

    s1=Student("Adithya",438,90)
    s1.display()
    s2=Student("Pravallika",125,90)
    s2.display()
    s3=Student("Ashwika",437,100)
    s3.display()