s="  Hello  "
print(s.strip())