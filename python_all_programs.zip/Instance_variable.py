class Student:
    def __init__(self, name, roll_no):
        # 1. Instance variables created inside constructor using self
        self.name = name
        self.roll_no = roll_no
        print("Inside Constructor:")
        print("Name:", self.name)
        print("Roll Number:", self.roll_no)

    def update_marks(self, marks):
        # 2. Instance variable created inside instance method using self
        self.marks = marks
        print("\nInside Instance Method:")
        print(f"{self.name}'s Marks:", self.marks)


# Creating object of Student
s1 = Student("Anil", 101)
s1.update_marks(95)  # Example call to update marks
