def even_odd(num):
    if num%2==0:
        print(num,"is Even NUmber")
    else:
        print(num,"is Odd Number")
even_odd(10)
even_odd(15)    