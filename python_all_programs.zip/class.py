class car:
    def int(self,make,model,year,color):
        selfmake = make
        selfmodel = model
        selfyear = year
        selfcolor = color
        selfspeed =0 

#creating instances (objects) of car
car1 = car("Toyota","Camry",2022,"Red")
car2 = car("Ford","Mustang",2023,"Black")
print(car1.make)
print(car2.speed)        