class ADITYA:
    @staticmethod
    def add(x, y):
        print("The Sum value is:", (x + y))

    @staticmethod
    def sub(x, y):
        print("The Subtraction value is:", (x - y))

    @staticmethod
    def avg(x, y):
        print("The Average value is:", (x + y) / 2)

ADITYA.add(200, 100)
ADITYA.sub(200, 100)
ADITYA.avg(200, 100)
