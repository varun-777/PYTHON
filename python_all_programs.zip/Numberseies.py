
for num in range(8, 70, 3):
    print(num, end=", ")
